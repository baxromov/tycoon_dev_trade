IqOption trader is a simple and easy-to-use tool for trading binary options.

Don't use it in a real account.

It is under development.
